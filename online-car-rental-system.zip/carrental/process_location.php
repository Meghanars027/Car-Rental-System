<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the input value
    $location = $_POST['location'];

    // Sanitize the input to prevent malicious code
    $location = htmlspecialchars($location);

    // Use or display the data
    echo "You entered: " . $location;
}
?>
